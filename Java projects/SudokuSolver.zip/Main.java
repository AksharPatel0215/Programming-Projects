class Main {

  private static final int GRID_SIZE = 9;

  public static void main(String[] args) {
    int[][] board = {
    {0, 0, 0, 0, 6, 0, 0, 0, 0},
    {0, 0, 4, 5, 0, 7, 0, 9, 0},
    {0, 3, 0, 0, 0, 0, 8, 0, 0},
    {8, 0, 0, 2, 0, 6, 9, 0, 0},
    {0, 0, 0, 0, 4, 0, 0, 6, 0},
    {0, 0, 2, 0, 1, 0, 0, 0, 0},
    {0, 0, 5, 9, 0, 2, 0, 7, 0},
    {0, 0, 0, 1, 0, 0, 0, 0, 0},
    {4, 0, 0, 0, 0, 0, 0, 0, 5}
    };

    System.out.println("Before");
for(int i = 0; i < board.length; i++){
        if(i%3==0&&i!=0){
          System.out.println("-----------");
        }
        for(int j = 0; j < board[i].length; j++){
          if(j%3==0&&j!=0){
            System.out.print("|");
          }
          if(board[i][j]==0){
            System.out.print(" ");
          } else {
          System.out.print(board[i][j]);
          }
        }
        System.out.println();
      }

      System.out.println();
      if(solve(board)){
    System.out.println("After");
      for(int i = 0; i < board.length; i++){
        if(i%3==0&&i!=0){
          System.out.println("-----------");
        }
        for(int j = 0; j < board[i].length; j++){
          if(j%3==0&&j!=0){
            System.out.print("|");
          }
          System.out.print(board[i][j]);
        }
        System.out.println();
      }
      }

  }
  private static boolean inRow(int[][] board, int num, int row){

    for(int i = 0; i < GRID_SIZE; i++){
      if(board[row][i]==num)
        return true;
    }
    return false;
  }

  private static boolean inCol(int[][] board, int num, int col){
    for(int i = 0; i < GRID_SIZE; i++){
      if(board[i][col]==num)
        return true;
    }
    return false;
  }
  

  private static boolean inBox(int[][] board, int num, int row, int col){
    int locRow = row - row%3;
    int locCol = col - col%3;

    for(int i = locRow; i <locRow+3; i++){
      for(int j = locCol; j<locCol+3; j++){
          if(board[i][j]==num){
            return true;
        }
      }
    }
    return false;
  }

  private static boolean isVal(int[][] board, int num, int row, int col){

    return !inRow(board, num, row) && !inCol(board, num, col) && !inBox(board, num, row, col);
  }

  private static boolean solve(int[][] board){
    for(int i = 0; i < GRID_SIZE; i++){
      for(int j = 0; j < GRID_SIZE; j++){
        if(board[i][j]==0){
          for(int tryNum = 1; tryNum <= GRID_SIZE; tryNum++){
            if(isVal(board, tryNum, i, j)){
              board[i][j]=tryNum;
            
            if(solve(board)){
            return true;
            } else {
              board[i][j]=0;
              }
            }
          }     
          return false;  
        }
      }
    }
    return true;
  }
}