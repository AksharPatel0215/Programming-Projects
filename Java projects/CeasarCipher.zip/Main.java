import java.util.ArrayList;
class Main {
  public static void main(String[] args) {

    //Vjku ku vjg ugetgv eqfg.


    System.out.println(bruteCipher("Hfwfrjq nx ltti."));
  }

  //Cipher
  public static String Cipher(String str, int key){
    String newStr = "";

    if(key > 24 || key < -24){
      key = key%24 *-1;
    }
    for(int i = 0; i < str.length(); i++){
      char c = str.charAt(i);
      if(c >= 65 && c<= 90){
        c += key;
        if( c > 90){
          c -= 26;
        } else if(c < 65){
          c += 26;
        }
      } else if(c>= 97 && c<= 122){
        c += key;
        if( c > 122){
          c -= 26;
        } else if(c < 97){
          c += 26;
        }
      }
      newStr += c;
    }
    return newStr;
  }

  //
  public static String bruteCipher(String str){
    ArrayList<String> words = new ArrayList<String>();
    ArrayList<String> mostCommon = wordList("the at there	some my of be use her than and this an would first a have each make water to from which like been in or she him call is one do into who you had how time oil that by their has its it word if look now he but will two find was not up more long for what other write down on all about go day are were out see did as we many number get with when then no come his your them way made they can these could may I said so people part");
    int largest = 0;
    int index = 0;
    for(int i = 1; i < 27; i++){
      String test = Cipher(str, i);
      words = wordList(test);
      words.retainAll(mostCommon);
      if(words.size()>largest){
        largest = words.size();
        index = i;
      }
    }

    return str+"--->"+Cipher(str, index);
  }

  public static ArrayList<String> wordList(String str){
    ArrayList<String> list = new ArrayList<String>();
    for(int i = 0; i <str.length(); i++){
      if(i == str.length()-1){
        if(str.charAt(i)== 46 || str.charAt(i)== 33 || str.charAt(i)== 63){
          list.add(str.substring(0, i).toLowerCase());
        } else {
          list.add(str.toLowerCase());
        }
      } else if(str.charAt(i) < 65 || str.charAt(i) > 90 && str.charAt(i) < 97 || str.charAt(i) > 122){
        list.add(str.substring(0, i).toLowerCase());
        str = str.substring(str.indexOf(" ")+1);
        i = 0;
      } 
    }
    return list;
  }
}