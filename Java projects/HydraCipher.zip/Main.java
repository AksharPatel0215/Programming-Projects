import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    for( int i = 0; i != -1; i++){
    System.out.println("\nInput message to cipher.\nDo not use any characters besides letters and the space bar.\nType -1 if you wish to stop\n");
    String message = scan.nextLine();
    if(message.equals("-1")){
      return;
      }
    Hydra(message);
    }  
  }



  public static void Hydra(String str){
//hello
//19 23 7 0 3
    
str = " "+str.toLowerCase()+" ";
    //for every character
    for(int i = 1; i < str.length(); i++){
      //x is the char val of current letter
      int x = str.charAt(i)-96;
      //n represents the letter before
      int n;
      //if its the first letter then subtract 64 & set n to the last letter of that word. 
      if(str.charAt(i-1)==' '){  
        str = str.substring(i);
        n = str.charAt(str.indexOf(" ")-1)-96;
        if(x < n){
        x+=26;
      }x-=n;
      System.out.print(x+" ");
        i = 0;
      } else if(str.charAt(i) == ' '){
System.out.println("[]");
      } else {
        n = str.charAt(i-1)-96;
        if(x < n){
        x+=26;
      }x-=n;
      System.out.print(x+" ");
      }
    }
  }
}